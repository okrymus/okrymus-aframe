import WebVRPolyfill from "webvr-polyfill";
import StartAudioContext from "startaudiocontext";
import Tone from "tone";
import * as webvrui from "webvr-ui";
import { isMobile, isTablet } from "../../../utils/Helpers";

var WebVRConfig = new WebVRPolyfill();

const getComponentProperty = AFRAME.utils.entity.getComponentProperty;
const setComponentProperty = AFRAME.utils.entity.setComponentProperty;

AFRAME.registerComponent("splash", {
  flyTweenPosition: undefined,
  flyTweenRotation: undefined,
  isFirstTime: true,
  viewer: false,
  mode: undefined,
  camPos: { x: 0, y: 0, z: 0 },

  init() {
    WebVRConfig.CARDBOARD_UI_DISABLED = false;
    WebVRConfig.ENABLE_DEPRECATED_API = true;
    WebVRConfig.ROTATE_INSTRUCTIONS_DISABLED = false;
  },

  play() {
    const aScene = document.querySelector("a-scene");
    const tryItIn360 = document.getElementById("try-it-in-360");
    const enterVRContainer = splash.querySelector("#enter-vr-container");
    // create the webvr-ui Button
    const enterVRButton = new webvrui.EnterVRButton(null, {
      color: "#ffffff",
      corners: "square",
      onRequestStateChange: state => {
        // if(state === webvrui.State.PRESENTING){
        // 	enterVRButton.setTitle('WAITING');
        // }
        return true;
      },
      textEnterVRTitle: "loading".toUpperCase()
    });

    enterVRButton.domElement.addEventListener(
      "click",
      () => enterVRButton.setTitle("WAITING"),
      true
    );

    function createEnter360Button() {
      enterVRContainer.innerHTML = "";
      const enter360 = document.createElement("button");
      enter360.classList.add("webvr-ui-button");
      enter360.style.color = "white";
      enter360.innerHTML = `<div class="webvr-ui-title" style="padding: 0;">LOADING</div>`;
      enterVRContainer.appendChild(enter360);
      enter360.addEventListener("click", onEnter360);
      tryItIn360.style.display = "none";
      return enter360;
    }

    function onEnter360() {
      splash.classList.remove("visible");
    }

    // createEnter360Button();
    if (isTablet()) {
      createEnter360Button();
    }
    // loadingButton();

    enterVRButton.on("ready", () => {
      const display = enterVRButton.manager.defaultDisplay;
      if (display) {
        GA("vr-display", display.displayName);
        aScene.setAttribute("headset", display.displayName);
      }
      enterVRButton.domElement.style.marginBottom = "10px";
      if (!isTablet()) {
        enterVRContainer.insertBefore(
          enterVRButton.domElement,
          enterVRContainer.firstChild
        );
      }
      tryItIn360.style.display = "inline-block";
    });

    enterVRButton.on("enter", () => {
      splash.classList.remove("visible");
      splashScene.close();
      aScene.play();
      aScene.enterVR();
    });

    enterVRButton.on("exit", () => {
      aScene.exitVR();
      aScene.pause();
      splash.classList.add("visible");
      splashScene.start();
    });

    enterVRButton.on("error", () => {
      if (
        enterVRButton.state === webvrui.State.ERROR_NO_PRESENTABLE_DISPLAYS ||
        enterVRButton.state === webvrui.State.ERROR_BROWSER_NOT_SUPPORTED
      ) {
        createEnter360Button();
      }
    });

    StartAudioContext(Tone.context, [".webvr-ui-button", "#enter-360"]);

    // function createEnter360Button() {
    //   enterVRContainer.innerHTML = "";
    //   const enter360 = document.createElement("button");
    //   enter360.classList.add("webvr-ui-button");
    //   enter360.style.color = "white";
    //   enter360.innerHTML = `<div class="webvr-ui-title" style="padding: 0;">LOADING</div>`;
    //   enterVRContainer.appendChild(enter360);
    //   enter360.addEventListener("click", onEnter360);
    //   tryItIn360.style.display = "none";
    //   GA("vr-display", "none");
    //   return enter360;
    // }
    this._progressBar();
    enterVRContainer.classList.add("ready");
    //if WebVR is available and its not polyfill on a tablet
    if (
      enterVRButton.state === webvrui.State.READY_TO_PRESENT &&
      !(isMobile() && isTablet())
    ) {
      enterVRButton.setTitle("Enter VR".toUpperCase());
    } else if (
      isTablet() ||
      (enterVRButton.state || "").indexOf("error") >= 0
    ) {
      document.querySelector(".webvr-ui-title").innerHTML =
        '<img src="./images/360_icon.svg"><span>ENTER 360</span>';
      document.querySelector(".webvr-ui-title").classList.add("mode360");
    }

    // enterVRContainer.classList.add("ready");
    // console.log("ready");
    //   const always = () => {
    //       //if WebVR is available and its not polyfill on a tablet
    //       if (enterVRButton.state === webvrui.State.READY_TO_PRESENT && !(isMobile() && isTablet())) {
    //           enterVRButton.setTitle('Enter VR'.toUpperCase());
    //       } else if (isTablet() || (enterVRButton.state || '').indexOf('error') >= 0) {
    //           document.querySelector('.webvr-ui-title').innerHTML = '<img src="./images/360_icon.svg"><span>ENTER 360</span>';
    //           document.querySelector('.webvr-ui-title').classList.add('mode360')
    //       }
    //   };
    // createEnter360Button();
  },

  _progressBar() {
    const promises = [];
    let asset;

    for (let i = 0; i < 4000000000; i++) {
      //   console.log(i);
    }
    for (let i = 0; i < document.querySelectorAll("a-asset-item").length; i++) {
      asset = document.querySelectorAll("a-asset-item")[i];
      if (!asset.data) {
        promises.push(
          new Promise(done => {
            asset.addEventListener("loaded", done);
          })
        );
      }
    }
    promises.push(
      new Promise(done => {
        Tone.Buffer.on("load", done);
      })
    );
  }
});
