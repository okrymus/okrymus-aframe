import React from "react";

const AframeContent = () => (
  <a-scene splash vr-mode-ui="enabled: false"></a-scene>
);

export default AframeContent;
